AdlibDisable()

$a = AutoItWinGetTitle()

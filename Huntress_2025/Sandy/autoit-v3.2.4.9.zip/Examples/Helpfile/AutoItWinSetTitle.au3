AutoItWinSetTitle("My AutoIt Window")

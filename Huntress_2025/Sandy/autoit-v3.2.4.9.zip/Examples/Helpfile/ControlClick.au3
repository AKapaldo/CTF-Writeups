ControlClick("Untitled -", "", "MDIClient1")

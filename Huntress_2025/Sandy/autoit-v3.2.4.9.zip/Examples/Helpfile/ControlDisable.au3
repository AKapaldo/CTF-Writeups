ControlDisable("Untitled -", "", "MDIClient1")

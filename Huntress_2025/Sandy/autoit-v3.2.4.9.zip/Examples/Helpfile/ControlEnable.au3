ControlEnable("Untitled -", "", "MDIClient1")

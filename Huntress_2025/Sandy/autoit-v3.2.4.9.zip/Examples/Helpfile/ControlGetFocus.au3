$a = ControlGetFocus("Untitled - Notepad")

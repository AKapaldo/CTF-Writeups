ControlHide("Untitled -", "", "MDIClient1")

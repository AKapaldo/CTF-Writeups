ControlShow("Untitled -", "", "MDIClient1")

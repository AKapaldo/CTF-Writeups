WinMove("","",default, default, 200,300)	; just resize the active window (no move)

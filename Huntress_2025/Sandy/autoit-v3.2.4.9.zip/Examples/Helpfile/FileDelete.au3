FileDelete("D:\*.tmp")

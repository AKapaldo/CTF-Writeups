$size = FileGetSize("AutoIt.exe")

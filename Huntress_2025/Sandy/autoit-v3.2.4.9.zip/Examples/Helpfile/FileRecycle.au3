FileRecycle("C:\*.tmp")

FileRecycleEmpty("C:\")

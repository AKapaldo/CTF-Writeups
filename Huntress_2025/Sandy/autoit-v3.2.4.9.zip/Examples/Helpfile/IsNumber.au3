IsNumber(42)

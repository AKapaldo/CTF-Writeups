$x = IsString("foo")

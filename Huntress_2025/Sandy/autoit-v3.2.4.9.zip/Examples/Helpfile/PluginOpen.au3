$handle = PluginOpen("example.dll")

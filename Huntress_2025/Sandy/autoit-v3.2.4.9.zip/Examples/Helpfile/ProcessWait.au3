ProcessWait("notepad.exe")

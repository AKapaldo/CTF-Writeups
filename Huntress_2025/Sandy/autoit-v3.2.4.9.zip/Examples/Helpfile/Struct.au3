Struct $struct		; $struct = DllStructCreate("byte byte0[128]; byte byte1")
	byte byte0[128]	; Comments1
	byte byte1		; comment2
EndStruct

$s=DllStructSetData($struct, "byte0", 0,0)

DllStructSetData($struct, "byte0", 1,1)
DllStructSetData($struct, "byte0", 2,2)
DllStructSetData($struct, "byte0", 3,3)

$struct.byte1 = 1		; DllStructSetData($struct, "byte1", 1)

$var = $struct.byte0[2]	; $var = DllStructGetData($struct, "byte0", 3)
$var = $struct.byte0[0]	; $var = DllStructGetData($struct, "byte0", 1)

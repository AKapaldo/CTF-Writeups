WinClose("Untitled - Notepad", "")

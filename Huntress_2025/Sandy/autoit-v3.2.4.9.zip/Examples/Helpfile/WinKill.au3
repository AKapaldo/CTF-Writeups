WinKill("Untitled - ", "")

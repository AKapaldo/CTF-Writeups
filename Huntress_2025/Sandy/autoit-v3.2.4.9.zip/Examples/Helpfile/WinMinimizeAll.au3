WinMinimizeAll()

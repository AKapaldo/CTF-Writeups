WinMinimizeAllUndo()
